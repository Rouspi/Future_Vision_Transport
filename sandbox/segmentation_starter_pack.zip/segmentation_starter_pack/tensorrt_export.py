
# Modèle d'export TensorRT (à exécuter sur une machine avec TensorRT installé)
# Donne une idée du flux; adaptez selon votre environnement.

import os, time
import numpy as np
import tensorrt as trt
import onnx
import pycuda.driver as cuda
import pycuda.autoinit

onnx_path = "export/deeplabv3.onnx"
engine_path = "export/deeplabv3.trt"

# Construction de l'engine TensorRT
logger = trt.Logger(trt.Logger.WARNING)
builder = trt.Builder(logger)
network_flags = 1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)
network = builder.create_network(network_flags)
parser = trt.OnnxParser(network, logger)

with open(onnx_path, "rb") as f:
    assert parser.parse(f.read()), "Erreur de parsing ONNX"

config = builder.create_builder_config()
config.set_flag(trt.BuilderFlag.FP16)  # Optionnel: FP16 si supporté
engine = builder.build_engine(network, config)
with open(engine_path, "wb") as f:
    f.write(engine.serialize())
print("Engine TensorRT écrit:", engine_path)
