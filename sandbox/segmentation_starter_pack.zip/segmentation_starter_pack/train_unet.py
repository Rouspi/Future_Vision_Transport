
# Entraînement U-Net avec MLflow (sobre)

import os, time, numpy as np
import torch, torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
from torchvision.transforms.functional import to_tensor
from PIL import Image
from tqdm import tqdm
import mlflow
import mlflow.pytorch

from models.unet import UNet

device = "cuda" if torch.cuda.is_available() else "cpu"

class SegmentationDataset(Dataset):
    def __init__(self, img_dir, mask_dir, transform=None):
        self.img_dir = img_dir; self.mask_dir = mask_dir; self.transform = transform
        self.images = sorted([f for f in os.listdir(img_dir) if not f.startswith(".")])
    def __len__(self): return len(self.images)
    def __getitem__(self, idx):
        img = Image.open(os.path.join(self.img_dir, self.images[idx])).convert("RGB")
        mask = Image.open(os.path.join(self.mask_dir, self.images[idx]))
        img_t = to_tensor(img)
        mask_t = torch.from_numpy(np.array(mask)).long()
        if self.transform: img_t = self.transform(img_t)
        return img_t, mask_t

def compute_iou_per_class(pred, target, num_classes):
    if pred.ndim == 4: pred = pred.argmax(1)
    ious = []
    for cls in range(num_classes):
        pm = (pred == cls); tm = (target == cls)
        inter = (pm & tm).sum().item(); union = (pm | tm).sum().item()
        ious.append(float("nan") if union == 0 else inter/union)
    return ious, np.nanmean(ious)

def train_one_epoch(model, loader, optim, crit):
    model.train(); tot=0.0
    for x,y in tqdm(loader, leave=False):
        x,y=x.to(device),y.to(device)
        logits=model(x)
        loss=crit(logits,y)
        optim.zero_grad(); loss.backward(); optim.step()
        tot+=loss.item()
    return tot/ max(1,len(loader))

@torch.no_grad()
def validate(model, loader, crit, num_classes):
    model.eval(); tot=0.0; basket=[]
    for x,y in loader:
        x,y=x.to(device),y.to(device)
        logits=model(x); loss=crit(logits,y); tot+=loss.item()
        ious, miou = compute_iou_per_class(logits,y,num_classes); basket.append(ious)
    if basket:
        per_cls=np.nanmean(np.array(basket),axis=0); miou=np.nanmean(per_cls)
    else:
        per_cls=[float("nan")]*num_classes; miou=float("nan")
    return tot/ max(1,len(loader)), miou, per_cls

if __name__ == "__main__":
    img_tr, msk_tr = "data/train/images", "data/train/masks"
    img_va, msk_va = "data/val/images",   "data/val/masks"
    num_classes=5; epochs=10; bs=4; lr=1e-3

    tr_tf = transforms.Compose([transforms.RandomHorizontalFlip()])
    va_tf = None

    ds_tr = SegmentationDataset(img_tr, msk_tr, tr_tf)
    ds_va = SegmentationDataset(img_va, msk_va, va_tf)

    dl_tr = DataLoader(ds_tr, batch_size=bs, shuffle=True, num_workers=2, pin_memory=True)
    dl_va = DataLoader(ds_va, batch_size=bs, shuffle=False, num_workers=2, pin_memory=True)

    model = UNet(in_ch=3, num_classes=num_classes, base=32).to(device)
    crit = nn.CrossEntropyLoss()
    optim = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)

    mlflow.set_tracking_uri("mlruns")
    mlflow.set_experiment("segmentation_baseline_unet")
    mlflow.autolog(disable=True)

    best=float("-inf")
    with mlflow.start_run(run_name="unet_baseline"):
        mlflow.log_param("model","UNet")
        mlflow.log_param("num_classes",num_classes)
        mlflow.log_param("epochs",epochs)
        mlflow.log_param("batch_size",bs)
        mlflow.log_param("lr",lr)

        for ep in range(epochs):
            t0=time.time()
            tr=train_one_epoch(model, dl_tr, optim, crit)
            vl, miou, per = validate(model, dl_va, crit, num_classes)
            dt=time.time()-t0

            mlflow.log_metric("train_loss",tr,step=ep)
            mlflow.log_metric("val_loss",vl,step=ep)
            mlflow.log_metric("val_mIoU",float(miou),step=ep)
            mlflow.log_metric("epoch_time_sec",dt,step=ep)
            for c,iou in enumerate(per):
                if not np.isnan(iou):
                    mlflow.log_metric(f"IoU_class_{c}",float(iou),step=ep)

            print(f"[{ep:02d}] train {tr:.4f} | val {vl:.4f} | mIoU {miou:.4f} | {dt:.1f}s")
            if miou>best:
                best=miou
                torch.save(model.state_dict(),"best_model_unet.pth")
                mlflow.log_artifact("best_model_unet.pth")

        mlflow.pytorch.log_model(model,"model")
        print("Best mIoU:",best)
