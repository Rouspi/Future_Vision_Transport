
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
import torch
import io, time, os
from PIL import Image
from torchvision.transforms.functional import to_tensor
from torchvision.models.segmentation import deeplabv3_resnet50
import numpy as np

import mlflow

# Sobre: config simple
MODEL_PATH = os.getenv("MODEL_PATH", "model/best_model_deeplabv3.pth")
NUM_CLASSES = int(os.getenv("NUM_CLASSES", "5"))
MLFLOW_URI = os.getenv("MLFLOW_URI", "mlruns")
MLFLOW_EXPERIMENT = os.getenv("MLFLOW_EXPERIMENT", "segmentation_inference")

mlflow.set_tracking_uri(MLFLOW_URI)
mlflow.set_experiment(MLFLOW_EXPERIMENT)

app = FastAPI(title="Segmentation Inference API", version="1.0")

# Chargement du modèle (CPU par défaut pour simplicité)
model = deeplabv3_resnet50(weights=None)
model.classifier[-1] = torch.nn.Conv2d(256, NUM_CLASSES, 1)
state = torch.load(MODEL_PATH, map_location="cpu")
model.load_state_dict(state, strict=False)
model.eval()

def predict_mask(img: Image.Image):
    # Inférence sur une image PIL, retourne mask numpy (H,W)
    x = to_tensor(img).unsqueeze(0)
    with torch.no_grad():
        out = model(x)["out"]
        mask = out.argmax(1).squeeze().cpu().numpy()
    return mask

@app.get("/healthz")
def healthz():
    return {"status": "ok"}

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    # Lecture et inférence
    start = time.time()
    raw = await file.read()
    img = Image.open(io.BytesIO(raw)).convert("RGB")
    mask = predict_mask(img)
    latency_ms = (time.time() - start) * 1000.0

    # Logging MLflow minimal
    with mlflow.start_run(run_name="inference", nested=True):
        mlflow.log_param("image_size", f"{img.size[0]}x{img.size[1]}")
        mlflow.log_metric("latency_ms", latency_ms)
        # On ne log pas l'image brute par défaut; vous pouvez l'activer si besoin

    return JSONResponse({"height": int(mask.shape[0]), "width": int(mask.shape[1]), "latency_ms": latency_ms, "mask": mask.tolist()})
