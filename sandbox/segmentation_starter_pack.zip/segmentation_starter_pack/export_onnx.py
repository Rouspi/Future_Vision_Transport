
# Export ONNX à partir d'un modèle DeepLabV3+ sauvegardé

import torch
from torchvision.models.segmentation import deeplabv3_resnet50

model_path = "api/model/best_model_deeplabv3.pth"
num_classes = 5
onnx_path = "export/deeplabv3.onnx"

model = deeplabv3_resnet50(weights=None)
model.classifier[-1] = torch.nn.Conv2d(256, num_classes, 1)
model.load_state_dict(torch.load(model_path, map_location="cpu"), strict=False)
model.eval()

dummy = torch.randn(1,3,256,256)
torch.onnx.export(
    model, dummy, onnx_path,
    input_names=["input"], output_names=["logits"],
    opset_version=13, dynamic_axes={"input": {0: "batch", 2: "h", 3:"w"},
                                    "logits": {0: "batch", 2: "h", 3:"w"}}
)
print("ONNX exporté:", onnx_path)
