
import streamlit as st
import requests
import numpy as np
from PIL import Image
import io

st.title("Segmentation — Démo API (couleurs + overlay)")

api_url = st.text_input("URL de l'API /predict", value="http://localhost:8000/predict")

uploaded = st.file_uploader("Choisir une image", type=["jpg", "jpeg", "png"])

def colorize(mask):
    palette = [
        (0,0,0),(128,64,128),(244,35,232),(70,70,70),(102,102,156),
        (190,153,153),(153,153,153),(250,170,30),(220,220,0),(107,142,35),
        (152,251,152),(70,130,180),(220,20,60),(255,0,0),(0,0,142),
        (0,0,70),(0,60,100),(0,80,100),(0,0,230),(119,11,32),
    ]
    h, w = mask.shape
    out = np.zeros((h,w,3), dtype=np.uint8)
    for i, rgb in enumerate(palette):
        out[mask == i] = rgb
    return out

def overlay(img, cmask, alpha=0.5):
    if isinstance(img, Image.Image):
        img = np.array(img)
    if img.max() <= 1:
        base = (img*255).astype(np.uint8)
    else:
        base = img.astype(np.uint8)
    return (alpha*cmask + (1-alpha)*base).astype(np.uint8)

if uploaded and api_url:
    img = Image.open(uploaded).convert("RGB")
    st.image(img, caption="Image d'entrée", use_container_width=True)

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    files = {"file": ("image.png", buf, "image/png")}

    with st.spinner("Prédiction en cours..."):
        r = requests.post(api_url, files=files, timeout=120)

    if r.status_code == 200:
        data = r.json()
        mask = np.array(data["mask"], dtype=np.int64)
        cmask = colorize(mask)
        ov = overlay(img, cmask, alpha=0.5)
        st.image(cmask, caption="Masque colorisé", use_container_width=True)
        st.image(ov, caption="Overlay", use_container_width=True)
    else:
        st.error(f"Erreur API: {r.status_code} - {r.text}")
