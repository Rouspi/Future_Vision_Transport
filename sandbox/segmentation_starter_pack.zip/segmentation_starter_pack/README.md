
# Segmentation Starter Pack

Contenu :
- `notebooks/segmentation_baseline_mlflow.ipynb` — DeepLabV3+ + MLflow + visualisations
- `api/` — API FastAPI d'inférence + MLflow (latence)
- `streamlit/` — App Streamlit (masque colorisé + overlay)
- `models/unet.py` — U-Net léger
- `train_unet.py` — Script d'entraînement U-Net avec MLflow
- `export_onnx.py` — Export ONNX
- `tensorrt_export.py` — Gabarit TensorRT (nécessite TensorRT)

Démarrage rapide :
1. Entraînez le modèle (notebook ou `train_unet.py`).
2. Placez le `best_model_*.pth` dans `api/model/` et lancez l'API :
   ```bash
   uvicorn app:app --host 0.0.0.0 --port 8000
   ```
3. Lancez Streamlit :
   ```bash
   streamlit run app_streamlit.py
   ```

MLflow : les runs sont enregistrés dans `mlruns/` par défaut. Vous pouvez changer l'URI.
